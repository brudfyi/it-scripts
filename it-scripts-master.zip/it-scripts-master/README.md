# it-scripts

## A place for all IT scripts!


Used for automation across IT tools.

