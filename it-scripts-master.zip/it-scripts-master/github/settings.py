
# THIS IS FOR that weird gongshow teams script, probably useless
#
# 2020-01-03 - bjm - DON'T DO THIS, create a creds file with an extension like .inc, and add it to .gitignore
# or use .env and python-env like ghbackup.py
#
# Credentials

# Create token here: https://github.com/settings/tokens  Needs the "repo" permission.
GITHUB_TOKEN = ''
# The destination organization on Github.
GITHUB_ORG = ''
